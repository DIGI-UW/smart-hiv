# PrEP visit - TTL Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PrEP visit**

## : PrEP visit - TTL Representation

| |
| :--- |
| Active as of 2025-12-08 |

[Raw ttl](Requirements-HIV.C.PrEPvisit.ttl) | [Download](Requirements-HIV.C.PrEPvisit.ttl)

