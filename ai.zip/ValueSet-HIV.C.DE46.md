# Acute HIV infection symptoms ValueSet - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Acute HIV infection symptoms ValueSet**

## ValueSet: Acute HIV infection symptoms ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/ValueSet/HIV.C.DE46 | *Version*:0.4.4 |
| Active as of 2025-12-08 | *Computable Name*:HIVCDE46 |

 
Value set of symptoms that could suggest an acute HIV infection 

 **References** 

* [HIV.C PrEP visit](StructureDefinition-HIVCPrEPvisit.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HIV.C.DE46",
  "meta" : {
    "profile" : [
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"
    ]
  },
  "url" : "http://smart.who.int/hiv/ValueSet/HIV.C.DE46",
  "version" : "0.4.4",
  "name" : "HIVCDE46",
  "title" : "Acute HIV infection symptoms ValueSet",
  "status" : "active",
  "experimental" : true,
  "date" : "2025-12-08T16:41:10+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "Value set of symptoms that could suggest an acute HIV infection",
  "compose" : {
    "include" : [
      {
        "system" : "http://smart.who.int/hiv/CodeSystem/HIVConcepts",
        "concept" : [
          {
            "code" : "HIV.C.DE47",
            "display" : "Fever"
          },
          {
            "code" : "HIV.C.DE48",
            "display" : "Sore throat"
          },
          {
            "code" : "HIV.C.DE49",
            "display" : "Aches"
          },
          {
            "code" : "HIV.C.DE50",
            "display" : "Pains"
          },
          {
            "code" : "HIV.C.DE51",
            "display" : "Swollen glands"
          },
          {
            "code" : "HIV.C.DE52",
            "display" : "Mouth sores"
          },
          {
            "code" : "HIV.C.DE53",
            "display" : "Headaches"
          },
          {
            "code" : "HIV.C.DE54",
            "display" : "Rash"
          }
        ]
      }
    ]
  }
}

```
